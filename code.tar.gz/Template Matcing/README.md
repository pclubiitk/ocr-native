Getting 60 % accuracy


javac Getvector.java

java Getvector <Image Name in this folder>

Output of code
 
<Text Extracted from Image> 
